function move(rect1,rect2) {
    $('.Total').each(function(index,element){
    	element.classList.add('rect');
    }
}